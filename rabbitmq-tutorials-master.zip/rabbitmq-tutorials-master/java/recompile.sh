#!/bin/sh

javac -cp .:rabbitmq-client.jar *.java
